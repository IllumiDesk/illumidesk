# illumidesk

## Overview

- JupyterHub Authenticators
- JupyterHub Spawners
- JupyterHub REST API client

## Dev Install

Install in editable mode:

    python3 -m pip install -e .
